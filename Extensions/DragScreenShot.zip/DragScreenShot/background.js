chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CAPTURE') {
    // 1. Tell Chrome we will respond asynchronously
    captureTab().then(dataUrl => {
      sendResponse({ image: dataUrl });
    });
    return true; // REQUIRED for async response
  }
});

async function captureTab() {
  try {
    // 2. Wait a tiny bit to ensure overlay is gone
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // 3. Capture current window (null = current)
    // catch any errors inside the promise
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    return dataUrl;
  } catch (err) {
    console.error("SnapArea Background Error:", err);
    return null;
  }
}

chrome.action.onClicked.addListener((tab) => {
  // Check if we are on a restricted page
  if (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://")) {
    console.warn("SnapArea cannot run on browser settings pages.");
    return;
  }
  
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  }).catch(err => console.error("Script Injection Failed:", err));
});