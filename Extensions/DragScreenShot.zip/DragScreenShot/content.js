(async function () {
  console.log("SnapArea: Initializing...");

  if (document.getElementById('snaparea-overlay')) {
    document.getElementById('snaparea-overlay').remove();
    return;
  }

  // --- 1. Setup Overlay ---
  const docHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight);
  const docWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth, document.body.offsetWidth);

  const overlay = document.createElement('div');
  overlay.id = 'snaparea-overlay';
  Object.assign(overlay.style, {
    position: 'absolute', top: '0', left: '0',
    width: docWidth + 'px', height: docHeight + 'px',
    background: 'rgba(0,0,0,0.3)', cursor: 'crosshair', zIndex: '2147483647'
  });

  const box = document.createElement('div');
  Object.assign(box.style, {
    position: 'absolute', border: '2px dashed #ff0000', background: 'rgba(255,0,0,0.1)',
    display: 'none', pointerEvents: 'none', zIndex: '2147483647'
  });
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  // --- 2. Selection Logic ---
  let startX, startY, isSelecting = false;

  overlay.onmousedown = e => {
    isSelecting = true;
    startX = e.pageX;
    startY = e.pageY;
    box.style.display = 'block';
    updateBox(e.pageX, e.pageY);
  };

  overlay.onmousemove = e => {
    if (!isSelecting) return;
    updateBox(e.pageX, e.pageY);
  };

  overlay.onmouseup = async (e) => {
    if (!isSelecting) return;
    isSelecting = false;

    const rect = {
      left: Math.min(startX, e.pageX),
      top: Math.min(startY, e.pageY),
      width: Math.abs(e.pageX - startX),
      height: Math.abs(e.pageY - startY)
    };

    if (rect.width < 10 || rect.height < 10) {
      overlay.remove();
      return;
    }

    // Visual feedback
    overlay.style.cursor = 'wait';
    box.style.border = '2px solid #00ff00';
    box.style.background = 'none';

    await captureSeamless(rect);
    overlay.remove();
  };

  function updateBox(x, y) {
    box.style.left = Math.min(startX, x) + 'px';
    box.style.top = Math.min(startY, y) + 'px';
    box.style.width = Math.abs(x - startX) + 'px';
    box.style.height = Math.abs(y - startY) + 'px';
  }

  // --- 3. Robust Capture Logic ---
  async function captureSeamless(rect) {
    const images = [];
    const dpr = window.devicePixelRatio || 1;
    const viewportHeight = window.innerHeight;
    let currentCapturedHeight = 0;

    // A. Hide Overlay
    overlay.style.opacity = '0';

    // B. Lock Width & Hide Scrollbars
    // This prevents layout shifts when scrollbars disappear
    const originalWidth = document.body.style.width;
    const originalOverflow = document.body.style.overflow;
    document.body.style.width = document.body.clientWidth + 'px';
    document.body.style.overflowX = 'hidden'; 

    const styleObj = document.createElement('style');
    styleObj.textContent = `
      body::-webkit-scrollbar { display: none !important; }
      .snaparea-hide-fixed { visibility: hidden !important; opacity: 0 !important; }
    `;
    document.head.appendChild(styleObj);

    // C. Identify Fixed Elements
    const fixedElements = [];
    // Only checking elements that actually have dimensions to save performance
    const allElements = document.querySelectorAll('div, header, nav, footer, section, aside');
    for (const node of allElements) {
        const style = getComputedStyle(node);
        if ((style.position === 'fixed' || style.position === 'sticky') && node.id !== 'snaparea-overlay') {
             fixedElements.push(node);
        }
    }

    // D. Reset Scroll
    const htmlScroll = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';

    try {
        let isFirstSegment = true;

        while (currentCapturedHeight < rect.height) {
            const yPos = rect.top + currentCapturedHeight;
            window.scrollTo(0, yPos);

            // --- CRITICAL FIX: STRONGER HIDING ---
            if (!isFirstSegment) {
                fixedElements.forEach(el => el.classList.add('snaparea-hide-fixed'));
                
                // FORCE REPAINT: Accessing offsetHeight forces the browser to apply styles NOW
                void document.body.offsetHeight; 
            }

            // Wait a bit longer to ensure the "White Header" is truly gone from the GPU buffer
            await new Promise(r => setTimeout(r, 600)); 

            const response = await chrome.runtime.sendMessage({ type: 'CAPTURE' });
            if (!response?.image) break;

            const scrollY = window.scrollY;
            const selectionYInViewport = rect.top + currentCapturedHeight - scrollY;
            const remainingH = rect.height - currentCapturedHeight;
            const captureH = Math.min(viewportHeight - selectionYInViewport, remainingH);

            if (captureH <= 0) break;

            images.push({
                src: response.image,
                x: (rect.left - window.scrollX) * dpr,
                y: selectionYInViewport * dpr,
                w: rect.width * dpr,
                h: captureH * dpr
            });

            currentCapturedHeight += captureH;
            isFirstSegment = false; 
        }
    } finally {
        // E. Restore Everything
        document.documentElement.style.scrollBehavior = htmlScroll;
        styleObj.remove(); 
        document.body.style.width = originalWidth;
        document.body.style.overflow = originalOverflow;
        fixedElements.forEach(el => el.classList.remove('snaparea-hide-fixed'));
    }

    await stitchImages(images, rect.width * dpr, rect.height * dpr);
  }

  async function stitchImages(parts, w, h) {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');

    let dy = 0;
    for (const part of parts) {
        const img = await new Promise(r => {
            const i = new Image();
            i.onload = () => r(i);
            i.src = part.src;
        });
        
        ctx.drawImage(
            img,
            part.x, part.y, part.w, part.h,
            0, Math.round(dy), part.w, part.h
        );
        dy += part.h;
    }

    const a = document.createElement('a');
    a.download = `snaparea_${Date.now()}.png`;
    a.href = canvas.toDataURL();
    a.click();
  }
})();