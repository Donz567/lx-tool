chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url.includes("basecamp.com")) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (command) => {
      // Helper to click toolbar buttons
      function clickButton(selector) {
        const btn = document.querySelector(selector);
        if (btn) {
          // Lexical buttons often need the full click sequence to register
          btn.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
          btn.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
          btn.click(); 
        }
      }

      // Find the new Lexical/Lexxy content editor
      const editor = document.querySelector('.lexxy-editor__content[contenteditable="true"]');
      
      if (!editor || editor.offsetParent === null) {
        console.warn("⚠️ No active Basecamp editor found, shortcut ignored.");
        return;
      }

      // Make sure it's focused
      editor.focus();

      // Click the new Lexxy Quote button
      clickButton('button[data-command="insertQuoteBlock"]');
      
      // Short delay to let the Lexical state update the UI
      setTimeout(() => {
        // Click the new Lexxy Bold button
        clickButton('button[data-command="bold"]');
        
        setTimeout(() => {
          const text =
            command === "status-shortcut" ? "Status: Ongoing" :
            command === "notes-shortcut" ? "Notes: " : "";

          if (text) {
            // Use execCommand to simulate native typing. 
            // This is crucial: it forces Lexical to recognize the text and update its internal state!
            document.execCommand("insertText", false, text);
            
            // Turn off bold by clicking the button again
            clickButton('button[data-command="bold"]');
            
            // Insert a trailing space so the user can keep typing in normal weight
            document.execCommand("insertText", false, " ");
            
            console.log(`✅ Quote + Bold active, inserted "${text}" into Lexical`);
          }
        }, 100);
      }, 100);
    },
    args: [command],
  });
});