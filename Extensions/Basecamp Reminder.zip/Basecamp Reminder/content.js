const trackerInfo = {
    "37340191": {
        name: "2P",
        url: "https://docs.google.com/spreadsheets/d/1ASwsqM58jUQb5-SVeCj7dAXR9WV0tyUvP6T3xG0PaUU/edit?gid=0#gid=0"
    },
    "742926": {
        name: "3P",
        url: "https://docs.google.com/spreadsheets/d/1X0MpZ2U1zaKSScCIoXGRB667cJgdSBu6eAsoAZ9V5uU/edit?gid=1887139564#gid=1887139564"
    }
};

function getModalContainer() {
    let container = document.getElementById('bc-modal-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'bc-modal-container';
        container.style.position = 'fixed';
        container.style.top = '0';
        container.style.left = '0';
        container.style.width = '100%';
        container.style.height = '100%';
        container.style.pointerEvents = 'none';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
    }
    return container;
}

function showModal(todoTitle, trackerName, trackerUrl) {
    const container = getModalContainer();

    // Clear any old modals
    container.innerHTML = "";

    const backdrop = document.createElement('div');
    backdrop.className = 'bc-modal-backdrop';
    backdrop.style.pointerEvents = 'auto';
    backdrop.style.position = 'fixed';
    backdrop.style.top = '0';
    backdrop.style.left = '0';
    backdrop.style.width = '100%';
    backdrop.style.height = '100%';
    backdrop.style.background = 'rgba(0,0,0,0.5)';
    backdrop.style.display = 'flex';
    backdrop.style.justifyContent = 'center';
    backdrop.style.alignItems = 'center';

    const modalBox = document.createElement('div');
    modalBox.className = 'bc-modal-box';
    modalBox.style.background = '#fff';
    modalBox.style.padding = '20px';
    modalBox.style.borderRadius = '10px';
    modalBox.style.boxShadow = '0 4px 10px rgba(0,0,0,0.2)';
    modalBox.style.maxWidth = '400px';
    modalBox.style.textAlign = 'center';

    modalBox.innerHTML = `
        <p><strong>${todoTitle}</strong></p>
        <p>This is for the <strong>${trackerName}</strong> tracker.</p>
        <a href="${trackerUrl}" target="_blank">Go to Tracker</a><br/><br/>
        <button class="bc-modal-close">Close</button>
    `;

    modalBox.querySelector('.bc-modal-close').addEventListener('click', () => {
        container.innerHTML = "";
    }, { once: true }); // close listener only once

    backdrop.appendChild(modalBox);
    container.appendChild(backdrop);
}

function handleCheckbox(checkbox) {
    if (!checkbox.checked) return; // Only when checked

    const todoTitle = checkbox.getAttribute('aria-label') || "Todo";
    const url = checkbox.getAttribute('data-url') || "";
    const bucketMatch = url.match(/buckets\/(\d+)\//);
    const bucketId = bucketMatch ? bucketMatch[1] : "";
    const tracker = trackerInfo[bucketId] || { name: "Unknown", url: "#" };

    // Delay so Basecamp can finish its re-render
    setTimeout(() => {
        showModal(todoTitle, tracker.name, tracker.url);
    }, 2000);
}

function attachCheckboxEvents() {
    const checkboxes = document.querySelectorAll('input.checkbox__input[data-behavior="todo_completion"]');

    checkboxes.forEach(cb => {
        if (!cb.dataset.reminderAdded) {
            cb.addEventListener('change', () => handleCheckbox(cb));
            cb.dataset.reminderAdded = "true";
        }
    });
}

// Initial attach
attachCheckboxEvents();

// Keep watching for new checkboxes after Basecamp reloads parts of the page
const observer = new MutationObserver(attachCheckboxEvents);
observer.observe(document.body, { childList: true, subtree: true });
